txt=input(str("Bir kelime giriniz:"))
Z=int(input("Bir sayı giriniz:"))
txt1=txt[: Z]
txt2=txt[Z :]
txt=txt1+"-"+txt2
print(txt)