not_1=int(input("not1:"))
not_2=int(input("not2:"))
not_3=int(input("not3:"))
toplam_n=(not_1+not_2+not_3)


ortalama=toplam_n/3
print(ortalama)
