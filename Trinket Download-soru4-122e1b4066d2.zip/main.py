Kelime_gir=input(str("Kelime giriniz:"))
print(Kelime_gir[1:])