soz_girdi=input(str("Bir sözcük giriniz:"))
print(len(soz_girdi))