Ad_gir=input(str("Adınızı girin:"))
Soyad_gir=input(str("Soyadınızı girin:"))
print( Ad_gir[0]+"."+Soyad_gir[0]+".")