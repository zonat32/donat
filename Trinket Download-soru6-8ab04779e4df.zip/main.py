txt=input(str("Kelime giriniz:"))
Z=int(input("bir sayı gir:"))
Harf=input("Harf giriniz:")
print(txt[0:Z-1])+Harf+txt[Z:])