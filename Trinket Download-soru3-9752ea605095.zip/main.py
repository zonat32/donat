Kelime_gir=input(str("Bir kelime girin:"))
print(Kelime_gir[:-6])