x1=int(input("noktayı girin:"))
y1=int(input("noktayı girin:"))
x2=int(input("noktayı girin:"))
y2=int(input("noktayı girin:"))

Ent=((x2-x1)**1/2)+((y2-y1)**1/2)
print(Ent)